M.E. Big Data and Data Analytics

2nd Semester Mini-Project

Project title: Sales Forecasting using Time Series and Neural Networks

Members:

Carol Dcunha		171046001

Sushmitha Shetty	171046037
